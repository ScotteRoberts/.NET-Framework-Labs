﻿using DataAccess_Layer;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Business_Layer
{
    /// <summary>
    /// Implementation of all the business rules relating to the
    /// Standard and Student tables.
    /// Includes CRUD operations.
    /// </summary>

    public class BusinessLayer : IBusinessLayer
    {
        // Local Repositories
        private readonly IStandardRepository standardRepository;
        private readonly IStudentRepository studentRepository;
        public BusinessLayer()
        {
            standardRepository = new StandardRepository();
            studentRepository = new StudentRepository();
        }

        // Adding a standard to the repository.
        public void AddStandard(Standard standard)
        {
            standardRepository.Insert(standard);
        }

        // Adding a student to the repository.
        public void AddStudent(Student student)
        {
            studentRepository.Insert(student);
        }

        // Retrieving a list of standards.
        public IList<Standard> GetAllStandards()
        {
            IQueryable<Standard> query = standardRepository.GetAll();
            return query.ToList();
        }

        // Retrieving a list of students.
        public IList<Student> GetAllStudents()
        {
            IQueryable<Student> query = studentRepository.GetAll();
            return query.ToList();
        }

        // Retrieving a Standard by ID.
        public Standard GetStandardByID(int id)
        {
            return standardRepository.GetByID(id);
        }

        // Retrieving a Student by ID.
        public Student GetStudentByID(int id)
        {
            return studentRepository.GetByID(id);
        }

        // Removing a standard and its student entities.
        public void RemoveStandard(Standard standard)
        {
            /*
            if(standard.Students.Count != 0)
            {
                // Grab all the student references and set their StandardID to null.
                foreach (Student s in standard.Students.ToList())
                {
                    s.StandardId = null;
                    s.Standard = null;
                }
                standard.Students.Clear();
            }
            */
            standardRepository.Delete(standard);
        }

        // Removing a student and the standard's reference
        public void RemoveStudent(Student student)
        {
            /*
            if(student.StandardId != null)
            {
                // Get the standard based on student's StandardID property.
                Standard standard = standardRepository
                    .GetSingle(d => d.StandardId == student.StandardId, d => d.Students);
                // Remove the reference to the student.
                standard.Students.Remove(student);
            }
            */
            
            // Delete the student.
            studentRepository.Delete(student);
        }

        // Modify a standard and all of its student references
        public void UpdateStandard(Standard standard)
        {
            
            standardRepository.Update(standard);
        }

        // Modify a student.
        public void UpdateStudent(Student student)
        { 
            studentRepository.Update(student);
        }
    }
}
