﻿using System.Collections.Generic;
using DataAccess_Layer;

namespace Business_Layer
{
    /// <summary>
    /// Interface class for the Business Layer methods.
    /// </summary>
    public interface IBusinessLayer
    {
        IList<Standard> GetAllStandards();
        Standard GetStandardByID(int id);
        void AddStandard(Standard standard);
        void UpdateStandard(Standard standard);
        void RemoveStandard(Standard standard);

        IList<Student> GetAllStudents();
        Student GetStudentByID(int id);
        void AddStudent(Student student);
        void UpdateStudent(Student student);
        void RemoveStudent(Student student);
    }
}