﻿using Business_Layer;
using DataAccess_Layer;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Layer
{
    /// <summary>
    /// Driver program to test the features of the Business Layer logic.
    /// Uses Standard and Student Entities for testing.
    /// </summary>
    class Program
    {
        // Connection the business logic layer.
        static BusinessLayer businessLayer = new BusinessLayer();
        // Menu choice variable.
        static int choice = -1;
        // Indenting variable.
        const int indent1PadSize = 30;

        public static void Main(string[] args)
        {
            String input;
            do
            {
                PrintMenu();
                input = Console.ReadLine(); // Has glitch of exiting with no input.
                if(ValidateInput(input))
                {
                    switch(choice)
                    {
                        // Quit
                        case 0:
                            break;
                        // Add New Standard
                        case 1:
                            AddNewStandard();
                            break;
                        // Update Standard
                        case 2:
                            UpdateStandardByID();
                            break;
                        // Delete Standard
                        case 3:
                            DeleteStandardByID();
                            break;
                        // Search for Standard by ID
                        case 4:
                            SearchStandardByID();
                            break;
                        // Display Student Related to Standard
                        case 5:
                            SearchStudentFromStandard();
                            break;
                        // Search All Standards
                        case 6:
                            DisplayAllStandards();
                            break;
                        // Add New Student
                        case 7:
                            AddNewStudent();
                            break;
                        // Update Student
                        case 8:
                            UpdateStudentByID();
                            break;
                        // Delete Student
                        case 9:
                            DeleteStudentByID();
                            break;
                        // Search for Student by ID
                        case 10:
                            SearchStudentByID();
                            break;
                        // Search All Students
                        case 11:
                            DisplayAllStudents();
                            break;
                    }
                }
            } while (choice != 0);
        }

        // Create a standard and 2 students as navigationProperty references.
        private static void AddNewStandard()
        {
            Standard s = new Standard
            {
                StandardName = "New standard",
                Description = "Welcome to the new world"
            };
            // Send to save the standard.
            businessLayer.AddStandard(s);
        }

        // Retrieve the Standard by ID and modify its name.
        private static void UpdateStandardByID()
        {
            Console.WriteLine("Enter the ID of the Standard you want to update: ");
            var decision = ReadIntChoice();
            Standard s = businessLayer.GetStandardByID(decision);
            if (s == null || s.StandardId != decision)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            else
            {
                int decision2 = -1;
                do
                {
                    PrintUpdateStandardMenu();
                    decision2 = ReadIntChoice();
                    switch (decision2)
                    {
                        case 0:
                            break;
                        case 1:
                            Console.WriteLine("What do you want the name to be?");
                            s.StandardName = Console.ReadLine();
                            Console.WriteLine("Standard name changed.");
                            break;
                        case 2:
                            Console.WriteLine("What do you want the description to be?");
                            s.Description = Console.ReadLine();
                            Console.WriteLine("Standard discription changed.");
                            break;
                        case 3: // Fix this
                            Student student = SearchStudentByID();
                            if (student != null)
                            {
                                student.StandardId = s.StandardId;
                                s.Students.Add(student);
                                businessLayer.UpdateStudent(student);
                            }  
                            break;
                    }
                } while (decision2 != 0);
                //businessLayer.UpdateStandard(s);
                Console.WriteLine("Modification Complete");
            }
        }

        static void PrintUpdateStandardMenu()
        {
            Console.WriteLine("Choose an option number to modify your standard.");
            Console.WriteLine("0. Exit");
            Console.WriteLine("1. Change Standard's Name");
            Console.WriteLine("2. Change Standard's Description");
            Console.WriteLine("3. Connect a Student to Standard\n");
        }

        static void UpdateStandardDecision(int decision)
        {
            
        }

        // Delete the standard by ID.
        private static void DeleteStandardByID()
        {
            Console.WriteLine("Enter the ID of the Standard you want to delete: ");
            var decision = ReadIntChoice();
            Standard s = businessLayer.GetStandardByID(decision);
            if (s == null || s.StandardId != decision)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            else
            {
                Console.WriteLine("Delete Standard method in progress...");
                businessLayer.RemoveStandard(s);
                Console.WriteLine("Delete done."); 
            }
        }

        // Search for single standard by ID and display its properties.
        private static Standard SearchStandardByID()
        {
            Console.Write("Enter Standard ID: ");
            var decision = ReadIntChoice();
            Standard s = businessLayer.GetStandardByID(decision);
            if (s == null || s.StandardId != decision)
            {
                Console.WriteLine("Standard not found!");
            }
            return s;
        }

        private static void DisplayStandard(Standard s)
        {
            var stdID = "Standard ID:".PadRight(indent1PadSize);
            var stdName = "Standard Name:".PadRight(indent1PadSize);
            var stdDescription = "Standard Description:".PadRight(indent1PadSize);
            Console.WriteLine(stdID + s.StandardId);
            Console.WriteLine(stdName + s.StandardName);
            Console.WriteLine(stdDescription + s.Description);
            Console.WriteLine();
        }

        // Search for a standard by ID, then get the students that belong to the standard.
        private static void SearchStudentFromStandard()
        {
            Console.Write("Enter Standard ID: ");
            int decision = ReadIntChoice();
            Standard s = businessLayer.GetStandardByID(decision);
            if (s == null)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            else if (s.Students == null || s.Students.Count == 0)
            {
                Console.WriteLine("This Standard has no Students!");
                return;
            }

            Console.WriteLine("\nContaining Students: {0}", s.Students.Count);
            foreach (Student student in s.Students)
                Console.WriteLine("- " + student.StudentName);

        }
        
        // Display every standard's information.
        private static void DisplayAllStandards()
        {
            var standards = businessLayer.GetAllStandards();
            foreach (Standard s in standards)
            {
                DisplayStandard(s);
                if (s.Students == null || s.Students.Count == 0)
                {
                    Console.WriteLine("This Standard has no Students!");
                }
                else
                {
                    Console.WriteLine("Containing Students: {0}", s.Students.Count);
                    foreach (Student student in s.Students)
                        Console.WriteLine("- " + student.StudentName);
                }
                
            }
        }

        // Add a single student.
        private static void AddNewStudent()
        {
            Console.WriteLine("What is the student's name?");
            string name = Console.ReadLine();
            Console.WriteLine("What is the student's standard id?");
            int standardID = ReadIntChoice();
            Student s = new Student
            {
                StudentName = name,
                StandardId = standardID
            };
            businessLayer.AddStudent(s);
            Console.WriteLine("Add Complete!");
        }

        // Retrieve the Standard by ID and modify its name.
        private static void UpdateStudentByID()
        {
            Console.WriteLine("Enter the ID of the Student you want to update: ");
            var decision = ReadIntChoice();
            Student s = businessLayer.GetStudentByID(decision);
            if (s == null || s.StudentID != decision)
            {
                Console.WriteLine("Standard not found!");
                return;
            }
            else
            {
                
                int decision2 = -1;
                do
                {
                    PrintUpdateStudentMenu();
                    decision2 = ReadIntChoice();
                    switch (decision2)
                    {
                        case 0:
                            break;
                        case 1:
                            Console.WriteLine("What do you want the name to be?");
                            s.StudentName = Console.ReadLine();
                            Console.WriteLine("Student name changed.");
                            break;
                        
                        case 2: // Fix this
                            Standard standard = SearchStandardByID();
                            if (standard != null)
                            {
                                s.StandardId = standard.StandardId;
                            }
                            break;
                    }
                } while (decision2 != 0);
                businessLayer.UpdateStudent(s);
                Console.WriteLine("Modification Complete");
            }
        }

        private static void PrintUpdateStudentMenu()
        {
            Console.WriteLine("What would you like to do to modify your student?");
            Console.WriteLine("0. Quit");
            Console.WriteLine("1. Change Student Name");
            Console.WriteLine("2. Add Standard Connection");
        }

        // Delete the student by ID.
        private static void DeleteStudentByID()
        {
            Console.WriteLine("Enter the ID of the Student you want to delete: ");
            var decision = ReadIntChoice();
            Student s = businessLayer.GetStudentByID(decision);
            if (s == null || s.StudentID != decision)
            {
                Console.WriteLine("Student not found!");
                return;
            }
            else
            {
                Console.WriteLine("Delete Student method in progress...");
                businessLayer.RemoveStudent(s);
                Console.WriteLine("Student has been deleted.");
            }
        }

        // Retreive a single student by ID and display student information.
        static Student SearchStudentByID()
        {
            Console.Write("Enter Student ID: ");
            var decision = ReadIntChoice();
            Student s = businessLayer.GetStudentByID(decision);
            if (s == null || s.StudentID != decision)
            {
                Console.WriteLine("Student not found!");
            }
            return s;
        }

        static void DisplayStudent(Student s)
        {
            var stdID = "Student ID:".PadRight(indent1PadSize);
            var stdName = "Student Name:".PadRight(indent1PadSize);
            var stdStandardID = "Student Standard ID:".PadRight(indent1PadSize);
            Console.WriteLine(stdID + s.StudentID);
            Console.WriteLine(stdName + s.StudentName);
            Console.WriteLine(stdStandardID + s.StandardId);
            Console.WriteLine();
        }

        // Display every student's information.
        static void DisplayAllStudents()
        {
            var students = businessLayer.GetAllStudents();
            foreach (Student st in students)
            {
                DisplayStudent(st);
            }
        }

        // Validate the integer input and return it when valid.
        static int ReadIntChoice()
        {
            int a = -1;
            var flag = false;
            while (!flag)
            {
                var input = Console.ReadLine();

                if (int.TryParse(input, out a))
                    flag = true;
                else
                    Console.WriteLine("You did not enter a number.");
            }
            return a;
        }

        // Validate the integer input with boolean return
        static bool ValidateInput(String input)
        {
            if (int.TryParse(input,out choice))
                return true;
            else
                Console.WriteLine("You did not enter the correct value!");
            return false;
        }
        // Console Print Menu.
        static void PrintMenu()
        {
            Console.WriteLine("*****************************************");
            Console.WriteLine("Please choose and option from 0-11:");
            Console.WriteLine("0. Exit");
            Console.WriteLine("1. Add New Standard");
            Console.WriteLine("2. Update Standard");
            Console.WriteLine("3. Delete Standard");
            Console.WriteLine("4. Search Standard");
            Console.WriteLine("5. Display Student related to Standard");
            Console.WriteLine("6. Display all Standards");
            Console.WriteLine("7. Add new Student");
            Console.WriteLine("8. Update Student");
            Console.WriteLine("9. Delete Student");
            Console.WriteLine("10. Search Student");
            Console.WriteLine("11. Display all Students");
            Console.WriteLine("******************************************");
        }  
    }
}
