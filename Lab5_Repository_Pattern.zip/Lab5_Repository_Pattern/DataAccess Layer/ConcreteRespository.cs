﻿namespace DataAccess_Layer
{
    /// <summary>
    /// Standard Repository Interface for Repository Pattern
    /// </summary>
    public interface IStandardRepository : IRepository<Standard>{}

    /// <summary>
    /// Student Repository Interface for Repository Pattern
    /// </summary>
    public interface IStudentRepository : IRepository<Student>{}

    /// <summary>
    /// Standard Repository using current assembly's entity connection
    /// </summary>
    public class StandardRepository : Repository<Standard>, IStandardRepository
    {
        public StandardRepository() : base(new SchoolDBEntities()) { }
    }

    /// <summary>
    /// Student Repository using current assembly's entity connection
    /// </summary>
    public class StudentRepository : Repository<Student>, IStudentRepository
    {
        public StudentRepository() : base(new SchoolDBEntities()) { }
    }
}
