﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace DataAccess_Layer
{
    /// <summary>
    /// Generic Repository CRUD Interface class
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IRepository<T> : IDisposable
    {
        void Insert(T entity);

        void Delete(T entity);

        void Update(T entity);

        T GetByID(int id);

        T GetSingle(Func<T, bool> where, params Expression<Func<T, object>>[] navigationProperties);

        IQueryable<T> SearchFor(Expression<Func<T, bool>> predicate);

        IQueryable<T> GetAll();
 
    }
}
